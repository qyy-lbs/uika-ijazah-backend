export type JenisDokumen = "ijazah" | "transkrip";

export type DocumentPageConfig = {
  pdfWidth: number;
  pdfHeight: number;
  canvasWidth: number;
  canvasHeight: number;
  defaultFontSize: number;
};

export function getDocumentPageConfig(jenis: JenisDokumen): DocumentPageConfig {
  if (jenis === "ijazah") {
    return {
      // Output PDF ijazah landscape
      pdfWidth: 1100,
      pdfHeight: 780,

      // Canvas frontend ijazah
      canvasWidth: 780,
      canvasHeight: 552,

      defaultFontSize: 12,
    };
  }

  return {
    // Output PDF transkrip portrait
    pdfWidth: 780,
    pdfHeight: 1100,

    // WAJIB sama dengan koordinat frontend transkrip
    // supaya x:292.5 tetap menjadi 292.5, tidak dikali lagi
    canvasWidth: 780,
    canvasHeight: 1100,

    defaultFontSize: 7,
  };
}